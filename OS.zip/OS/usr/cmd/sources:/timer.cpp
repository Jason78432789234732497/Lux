#include <iostream>
#include <thread>
#include <chrono>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "timer <seconds>\n";
        return 1;
    }

    int seconds = std::stoi(argv[1]);

    for (int i = seconds; i > 0; i--) {
        std::cout << i << "...\n";
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    std::cout << "timer: time's up!\n";
    return 0;
}

