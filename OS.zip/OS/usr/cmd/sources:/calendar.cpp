#include <iostream>
#include <chrono>
#include <ctime>

int main() {
    // get current system time
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);

    // convert to string
    char* raw = std::ctime(&t);

    if (!raw) {
        std::cout << "date: error reading time\n";
        return 1;
    }

    std::string s(raw);

    // remove trailing newline added by ctime()
    if (!s.empty() && s.back() == '\n')
        s.pop_back();

    std::cout << s << "\n";
    return 0;
}
